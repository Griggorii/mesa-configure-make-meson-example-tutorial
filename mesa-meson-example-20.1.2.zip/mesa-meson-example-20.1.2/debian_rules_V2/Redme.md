Griggorii@gmail.com


confflags_GLES = -Dgles1=true -Dgles2=true

-Dgallium-xvmc=true \
-Degl=true \
-Dshader-cache=auto \
-Dvalgrind=true \

https://github.com/Griggorii/mesa-configure-make-meson-example-tutorial/blob/master/README.md

meson example 2 + libXvMCr600.so , libXvMCnouveau.so <- dependency libdrm2 gallium-xvmc=true , gles1=true
